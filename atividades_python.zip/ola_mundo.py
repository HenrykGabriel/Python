# -*- coding: utf-8 -*-

def main():
    print("Olá, Mundo!")

if __name__ == "__main__":
    main()